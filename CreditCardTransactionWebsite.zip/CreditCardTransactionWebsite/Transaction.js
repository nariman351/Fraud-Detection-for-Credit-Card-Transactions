const okbutton = document.getElementById("okbutton");
okbutton.addEventListener("click", okbuttonfun);
function okbuttonfun(event) {
	document.querySelector(".popup").style.display = "none";
}

//User Creation function
//Start---------------------------------------------------------------------------------------------------------
async function postCreateFormDataAsJson({ url, formData }) {
	const plainFormData = Object.fromEntries(formData.entries());

	var currenturl = document.location.href;
	var username = currenturl.split('?')[1].split('=')[1];

	transactionData = {
		"username": username, "ccNumber": parseInt(plainFormData.ccNumber),
		"expMonth": parseInt(plainFormData.expMonth),
		"expYear": parseInt(plainFormData.expYear), "amount": parseFloat(plainFormData.amount)
	};

	const formDataJsonString = JSON.stringify(transactionData);
	const fetchOptions = {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Accept: "application/json",		
		},
		body: formDataJsonString,
	};

	const response = await fetch(url, fetchOptions);

	var responsestatus = { "status": response.ok, "message": await response.text() }
	return responsestatus;
}

async function handleFormSubmit(event) {
	event.preventDefault();

	const form = event.currentTarget;
	const url = form.action;

	try {
		const formData = new FormData(form);
		const responseData = await postCreateFormDataAsJson({ url, formData });

		console.log({ responseData });

		if (responseData.status == true) {
			document.querySelector(".popup").style.display = "block";
			document.getElementById("statusMessage").textContent = responseData.message;//"Transaction successful";
			document.getElementById("transaction").reset();

		}
		else {
			document.querySelector(".popup").style.display = "block";
			document.getElementById("statusMessage").textContent = responseData.message;//"Transaction denied. Seems like a fradulent transaction";
		}


	} catch (error) {
		console.error(error);
	}
}

const transactionForm = document.getElementById("transaction");
transactionForm.addEventListener("submit", handleFormSubmit);

//End---------------------------------------------------------------------------------------------------------

const logoutButton = document.getElementById("logoutButton");
logoutButton.addEventListener("click", logoutButtonfun);

async function logoutUserApiCall({ url }) {

	const fetchOptions = {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			Accept: "application/json",
		},
	};

	const response = await fetch(url, fetchOptions);

	var responsestatus = { "status": response.ok, "message": await response.text() }
	return responsestatus;
}

async function logoutButtonfun(event) {
	try {
		var url = document.location.href;
		var	username = url.split('?')[1].split('=')[1];
		url = 'http://ec2-35-182-145-79.ca-central-1.compute.amazonaws.com:5000/logoutUser/' + encodeURIComponent(username);


		const responseData = await logoutUserApiCall({ url });
		console.log({ responseData });

		if (responseData.status == true) {
			document.getElementById("transaction").reset();
			window.location.href = 'Index.html';

		}
		else {
			alert(responseData.message);
		}


	} catch (error) {
		console.error(error);
	}
}