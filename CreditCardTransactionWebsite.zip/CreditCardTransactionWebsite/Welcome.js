// Get the modal
var modal1 = document.getElementById('idlogin');
var modal2 = document.getElementById('idSignUp');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
	if (event.target == modal1) {
		modal1.style.display = "none";
	}
	else if (event.target == modal2) {
		modal2.style.display = "none";
	}
}


//User Login function
//Start---------------------------------------------------------------------------------------------------------
async function postLoginFormDataAsJson({ url, formData }) {
	const plainFormData = Object.fromEntries(formData.entries());

	const fetchOptions = {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			Accept: "application/json",
		}
	};
	var username = plainFormData.username;
	var password = plainFormData.passord;

	url = url + encodeURIComponent(username) + ',' + encodeURIComponent(password);

	const response = await fetch(url, fetchOptions);

	var responsestatus = { "status": response.ok, "message": await response.text() }
	return responsestatus;


}

async function handleloginSubmit(event) {
	event.preventDefault();

	const form = event.currentTarget;
	const url = form.action;

	try {
		const formData = new FormData(form);
		const responseData = await postLoginFormDataAsJson({ url, formData });

		console.log({ responseData });

		if (responseData.status == true) {
			const userName = document.querySelector('input').value;
			document.getElementById('idlogin').style.display = "none";
			document.getElementById("loginUser").reset();
			window.location.href = 'TransactionPage.html?username=' + encodeURIComponent(userName);
			
		}
		else {
			alert(responseData.message);
        }

		


	} catch (error) {
		console.error(error);
	}
}

const loginUserForm = document.getElementById("loginUser");
loginUserForm.addEventListener("submit", handleloginSubmit);

//End---------------------------------------------------------------------------------------------------------



//User Creation function
//Start---------------------------------------------------------------------------------------------------------
async function postCreateFormDataAsJson({ url, formData }) {
	const plainFormData = Object.fromEntries(formData.entries());
	const formDataJsonString = JSON.stringify(plainFormData);

	const fetchOptions = {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Accept: "application/json",
		},
		body: formDataJsonString,
	};

	const response = await fetch(url, fetchOptions);

	var responsestatus = { "status": response.ok, "message": await response.text() }
	return responsestatus;
}

async function handleFormSubmit(event) {
	event.preventDefault();

	const form = event.currentTarget;
	const url = form.action;

	try {
		const formData = new FormData(form);
		const responseData = await postCreateFormDataAsJson({ url, formData });

		console.log({ responseData });


		if (responseData.status == true) {
			alert(responseData.message);
			document.getElementById('idSignUp').style.display = "none";
			document.getElementById("CreateUser").reset();

		}
		else {
			alert(responseData.message);
		}

	} catch (error) {
		console.error(error);
	}
}

const CreateUserForm = document.getElementById("CreateUser");
CreateUserForm.addEventListener("submit", handleFormSubmit);

//End---------------------------------------------------------------------------------------------------------