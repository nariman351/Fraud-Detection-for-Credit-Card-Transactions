//User Creation function
//Start---------------------------------------------------------------------------------------------------------
async function postCreateFormDataAsJson({ url, formData }) {
	const plainFormData = Object.fromEntries(formData.entries());
	const formDataJsonString = JSON.stringify(plainFormData);

	var testData = { "firstName": plainFormData.firstname, "lastName": plainFormData.lastname, "email": plainFormData.email }
	testData = JSON.stringify(testData)

	const fetchOptions = {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Accept: "application/json",
		},
		body: testData,
	};

	const response = await fetch(url, fetchOptions);

	if (!response.ok) {
		const errorMessage = await response.text();
		throw new Error(errorMessage);
	}

	return response.json();
}

async function handleFormSubmit(event) {
	event.preventDefault();

	const form = event.currentTarget;
	const url = form.action;

	try {
		const formData = new FormData(form);
		const responseData = await postCreateFormDataAsJson({ url, formData });

		console.log({ responseData });

		if (responseData.status == true) {
			document.querySelector(".popup").style.display = "block";
			document.getElementById("transaction").reset();

		}
		else {
			document.querySelector(".popup").style.display = "block";
		}


	} catch (error) {
		console.error(error);
	}
}

const transactionForm = document.getElementById("transaction");
transactionForm.addEventListener("submit", handleFormSubmit);

//End---------------------------------------------------------------------------------------------------------