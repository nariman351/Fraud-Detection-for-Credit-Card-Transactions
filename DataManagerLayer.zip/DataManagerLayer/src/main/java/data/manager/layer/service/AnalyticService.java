package data.manager.layer.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AnalyticService {
	
	public AnalyticService() {
	}
	
	// Method: Send transaction details to Analytics and send results back
		// Successful: true
		// Unsuccessful: false
		public Boolean AnalyticResult(String user) {

			URL url;
			HttpURLConnection con = null;
			BufferedReader in;
			String inputLine;
			StringBuffer response = new StringBuffer();
			
			try {

				// Sending request
				url = new URL("http://integratedpreprocessmicro-env.eba-vxxpq39a.us-east-1.elasticbeanstalk.com/post");
				con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("POST");
				con.setRequestProperty("Content-Type", "application/json; utf-8");
				con.setRequestProperty("Accept", "application/json");
				con.setDoOutput(true);
				
				String jsonInputString = user;

				OutputStream os = con.getOutputStream();
				byte[] input = jsonInputString.getBytes("utf-8");
			    os.write(input, 0, input.length);
			    
			    System.out.print("------------------Start of Data Layer Output----------------------");
			    System.out.print(jsonInputString);
			    System.out.print("------------------End of Data Layer Output----------------------");

				// Reading response
				in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				
				while ((inputLine = in.readLine()) != null) { 
					response.append(inputLine);
				}
				
				// Disconnect connections and buffer readers
				in.close();
				con.disconnect();
				
			} catch (IOException e) {

				e.printStackTrace();
			}
			System.out.print(response.toString());
			// Verify the expected response type
			if (Boolean.valueOf(response.toString()) instanceof Boolean) {
				
				// returning response
				return Boolean.valueOf(response.toString());
			}
			
			// Default result
			return false;
		}

}
