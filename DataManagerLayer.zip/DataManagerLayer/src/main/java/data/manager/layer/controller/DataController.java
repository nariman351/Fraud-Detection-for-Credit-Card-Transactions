package data.manager.layer.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import data.manager.layer.service.AnalyticService;



@RestController
@RequestMapping("/api/Usertransaction")
public class DataController {
	
	AnalyticService callAnalyticService = new AnalyticService();
	
	@PostMapping("/Result")
	public Boolean userTransaction(@RequestBody String user) {
		return this.callAnalyticService.AnalyticResult(user);
	}

}
