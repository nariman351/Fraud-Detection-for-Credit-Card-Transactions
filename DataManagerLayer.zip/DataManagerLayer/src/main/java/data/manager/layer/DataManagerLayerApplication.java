package data.manager.layer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataManagerLayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataManagerLayerApplication.class, args);
	}

}
