
import numpy
import re
import pandas as pd
from sklearn.preprocessing import LabelEncoder



def process(df):
    #df['Is Fraud?']=df['Is Fraud?'].replace({'No':0,'Yes':1}) 
    df['Errors?']=df['Errors?'].fillna('NAN')
    df['Errors?']=df['Errors?'].apply(lambda value:value=='NAN')
    df['Use Chip'].unique()
    df['is online']=df['Use Chip'].apply(lambda value:value=='Online Transaction')
    df['Use Chip']=df['Use Chip'].replace({'Swipe Transaction':0, 'Online Transaction':1, 'Chip Transaction':2})
    df['Zip'] = df['Zip'].fillna(df['Zip'].mode())  
    # df['Amount'] = df['Amount'].apply(lambda value: float(value.split("$")[1]))
    #df['Hour'] = df['Time'].apply(lambda value: int(value.split(":")[0]))
    #df['Minutes'] = df['Time'].apply(lambda value: int(value.split(":")[1]))
    #df.drop(['Time'], axis=1, inplace=True)     
    df['Merchant State']=df['Merchant State'].fillna('NAN')    
    df['Merchant City']=df['Merchant City'].fillna('NAN') 
    # df['is vozmes']=df['Amount'].apply(lambda value: value<0)  
    # df['abs_amount']=df['Amount'].apply(lambda value: abs(value))
    le=LabelEncoder() 
    df['Merchant State']=le.fit_transform(df['Merchant State'])
    le=LabelEncoder()
    df['Merchant City']=le.fit_transform(df['Merchant City'])
    #df.drop('Merchant Name',axis=1,inplace=True)
    #df.drop('User',axis=1,inplace=True)
    #df = pd.concat([df['Is Fraud?'], df.drop(['Is Fraud?'], axis=1)], axis=1)
    df.replace({False: 0, True: 1}, inplace=True)
    # print("df:", df)
    return df