import numpy
import re
import pandas as pd

# def strToDF():
#     return "123123123"


def StrToDF(mystr):
  mydict = {'Card':[],'Year':[],'Month':[],'Day':[],'Amount':[],'Use Chip':[],'Merchant City':[],
          'Merchant State':[],'Zip':[],'MCC':[],'Errors?':[],'is online':[],'Hour':[],'Minutes':[],
          'is vozmes':[],'abs_amount':[]}
 
  mystr = re.sub(r'[{}]', '', mystr)
  mystr = re.sub(r'["]', '', mystr)
  mystr = re.sub(r'[/]', '', mystr)
  # mystr = re.sub(r'[\]', '', mystr)
  
  #print( mystr)
  mystr= mystr.split(",")
  #print( mystr)
  mydf = pd.DataFrame(mydict)
  
  mydf['Card']=[int((mystr[0].split(":"))[1] )]
  print( mydf['Card'])
  print(type( mydf['Card']))
  
  mydf['Year']=[int((mystr[4].split(":"))[1] )]
  mydf['Month']=[int((mystr[9].split(":"))[1] )]
  mydf['Day']=[int((mystr[3].split(":"))[1] )]
  mydf['Amount']=[float((mystr[5].split(":"))[1] )]
  mydf['Use Chip']=[(mystr[8].split(":"))[1] ]
#  mydf['Merchant City']=(mystr[0].split(":"))[1] 
  mydf['Merchant State']=[(mystr[2].split(":"))[1] ]
  mydf['Zip']=[int((mystr[7].split(":"))[1] )]
#  mydf['Zip'] = re.sub(r'["]', '', mydf['Zip'])
  
  mydf['MCC']=[int((mystr[1].split(":"))[1] )]
#  mydf['Errors?']=(mystr[0].split(":"))[1] 
  mydf['is online']=[0 ]
  mydf['Hour']=[int((mystr[6].split(":"))[1] )]
  mydf['Minutes']=[int((mystr[6].split(":"))[2] )] 
  mydf['is vozmes']=[0 ]
  mydf['abs_amount']=[int((mystr[5].split(":"))[1] )]
#  mydf['Is Fraud?']=''
  print("dataframe:\n", mydf)
  return mydf