
import pandas as pd
from sklearn.preprocessing import LabelEncoder
# import json

# data = '{ "card_number": 808878788, "merchant_MCC": 1234, "merchant_state": "NY", "postal_code": "12344", "transaction_amount": 8900, "transaction_day": 21, "transaction_month": 4, "transaction_time": "02:40", "transaction_year": 2022, "use_chip": "Online Transaction" }'
# data = json.loads(data)


def process2(data):
    columns = {'Card':[],'Year':[],'Month':[],'Day':[],'Amount':[],'Use Chip':[],'Merchant City':[],
            'Merchant State':[],'Zip':[],'MCC':[],'Errors?':[],'is online':[],'Hour':[],'Minutes':[],
            'is vozmes':[],'abs_amount':[]}

    df = pd.DataFrame(columns)
    df2 = {
        'Card':data['card_number'],
        'Year':data['transaction_year'],
        'Month':data['transaction_month'],
        'Day':data['transaction_day'],
        'Amount':data['transaction_amount'],
        'Use Chip':0,'Merchant City':"Albuquerque",
        'Merchant State':data['merchant_state'],
        'Zip':data['postal_code'],
        'MCC':data['merchant_MCC'],
        'Errors?':1,
        'is online':1,
        'Hour':data['transaction_time'],
        'Minutes':data['transaction_time'],
        'is vozmes':0,
        'abs_amount':data['transaction_amount']
        }

    df = df.append(df2, ignore_index = True)

    df['Zip'] = pd.to_numeric(df['Zip'])
    df['Hour'] = pd.to_numeric(df['Hour'].str.split(':').str[0])
    df['Minutes'] = pd.to_numeric(df['Minutes'].str.split(':').str[1])

    #df['Is Fraud?']=df['Is Fraud?'].replace({'No':0,'Yes':1}) 
    df['Errors?']=df['Errors?'].fillna('NAN')
    df['Errors?']=df['Errors?'].apply(lambda value:value=='NAN')
    df['Use Chip'].unique()
    df['is online']=df['Use Chip'].apply(lambda value:value=='Online Transaction')
    df['Use Chip']=df['Use Chip'].replace({'Swipe Transaction':0, 'Online Transaction':1, 'Chip Transaction':2})
    df['Zip'] = df['Zip'].fillna(df['Zip'].mode())  
    # df['Amount'] = df['Amount'].apply(lambda value: float(value.split("$")[1]))
    #df['Hour'] = df['Time'].apply(lambda value: int(value.split(":")[0]))
    #df['Minutes'] = df['Time'].apply(lambda value: int(value.split(":")[1]))
    #df.drop(['Time'], axis=1, inplace=True)     
    df['Merchant State']=df['Merchant State'].fillna('NAN')    
    df['Merchant City']=df['Merchant City'].fillna('NAN') 
    # df['is vozmes']=df['Amount'].apply(lambda value: value<0)  
    # df['abs_amount']=df['Amount'].apply(lambda value: abs(value))
    le=LabelEncoder() 
    df['Merchant State']=le.fit_transform(df['Merchant State'])
    le=LabelEncoder()
    df['Merchant City']=le.fit_transform(df['Merchant City'])
    #df.drop('Merchant Name',axis=1,inplace=True)
    #df.drop('User',axis=1,inplace=True)
    #df = pd.concat([df['Is Fraud?'], df.drop(['Is Fraud?'], axis=1)], axis=1)
    df.replace({False: 0, True: 1}, inplace=True)
    # print("df:", df)
    return df

# process2(data)
