from distutils.log import debug
from flask import Flask, request, render_template
import numpy
import re
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from strToDF import StrToDF
from process2 import process2
import json
import sys
import requests


application = Flask(__name__)


@application.route('/post', methods=['POST'])
def process_json():

    data = request.json

    df = process2(data)
    jsondf = df.reset_index(drop=True).to_json(orient='values')
    print(jsondf)


    lambda_API_Gateway_url = 'https://3jpfrvq75m.execute-api.us-east-1.amazonaws.com/post'
    preprocessed_result_data = jsondf
    response = requests.post(
            lambda_API_Gateway_url, data=preprocessed_result_data,
            headers={'Content-Type': 'application/json'}
        )
    if(response.text == 'true'):
    	result = True
    else:
    	result = False
    return json.dumps(result), 200, {'ContentType':'application/json'}





if __name__ == '__main__':
    application.run(debug=True)


